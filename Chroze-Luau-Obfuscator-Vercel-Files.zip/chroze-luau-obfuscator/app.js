'use strict';

const byId = (id) => document.getElementById(id);
const source = byId('source');
const output = byId('output');
const status = byId('status');
const obfuscateButton = byId('obfuscateButton');
const validateButton = byId('validateButton');

const sample = `local function greet(name: string): string
    local message = "Hello, " .. name .. "!"
    print(message)
    return message
end

greet("Luau")`;

function setStatus(message, kind = '') {
  status.textContent = message;
  status.className = 'status' + (kind ? ` ${kind}` : '');
}

function updateCounts() {
  byId('inputCount').textContent = `${source.value.length.toLocaleString()} characters`;
  byId('outputCount').textContent = output.value ? `${output.value.length.toLocaleString()} characters` : 'Waiting for code';
}

function currentOptions() {
  return {
    encodeStrings: byId('encodeStrings').checked,
    stripComments: byId('stripComments').checked,
    compact: byId('compact').checked,
    addBanner: byId('addBanner').checked
  };
}

async function sendJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  let data;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
  return data;
}

obfuscateButton.addEventListener('click', async () => {
  if (!source.value.trim()) {
    setStatus('Paste your Luau source code first.', 'error');
    source.focus();
    return;
  }
  obfuscateButton.disabled = true;
  validateButton.disabled = true;
  obfuscateButton.querySelector('span').textContent = 'Working…';
  setStatus('Transforming source…');
  try {
    const data = await sendJson('/api/obfuscate', { code: source.value, options: currentOptions() });
    output.value = data.output;
    byId('outputHash').textContent = `SHA-256: ${data.checksum}`;
    updateCounts();
    setStatus(`Done · ${data.tokenCount.toLocaleString()} tokens transformed. ${data.note}`, 'success');
  } catch (error) {
    setStatus(error.message || 'Transformation failed.', 'error');
  } finally {
    obfuscateButton.disabled = false;
    validateButton.disabled = false;
    obfuscateButton.querySelector('span').textContent = 'Transform source';
  }
});

validateButton.addEventListener('click', async () => {
  if (!source.value.trim()) {
    setStatus('Paste your Luau source code first.', 'error');
    source.focus();
    return;
  }
  validateButton.disabled = true;
  obfuscateButton.disabled = true;
  setStatus('Checking strings, comments, and paired delimiters…');
  try {
    const data = await sendJson('/api/validate', { code: source.value });
    setStatus(data.valid ? data.message : `Check failed: ${data.message}`, data.valid ? 'success' : 'error');
  } catch (error) {
    setStatus(error.message || 'Check failed.', 'error');
  } finally {
    validateButton.disabled = false;
    obfuscateButton.disabled = false;
  }
});

byId('loadSample').addEventListener('click', () => {
  source.value = sample;
  updateCounts();
  setStatus('Sample loaded. Click Transform source to test the app.');
});

byId('clearInput').addEventListener('click', () => {
  source.value = '';
  output.value = '';
  byId('outputHash').textContent = 'SHA-256: —';
  updateCounts();
  setStatus('Input and output cleared.');
  source.focus();
});

byId('copyOutput').addEventListener('click', async () => {
  if (!output.value) return setStatus('There is no output to copy yet.', 'error');
  try {
    await navigator.clipboard.writeText(output.value);
    setStatus('Output copied to clipboard.', 'success');
  } catch {
    output.focus();
    output.select();
    setStatus('Clipboard access was blocked. Output is selected; copy it manually.', 'error');
  }
});

byId('downloadOutput').addEventListener('click', () => {
  if (!output.value) return setStatus('There is no output to download yet.', 'error');
  const blob = new Blob([output.value], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'chroze-obfuscated.lua';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  setStatus('Downloaded chroze-obfuscated.lua.', 'success');
});

source.addEventListener('input', updateCounts);
updateCounts();
