'use strict';

const { validate } = require('../lib/luau');

module.exports = (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Use POST for this endpoint.' });
  }
  const body = req.body || {};
  return res.status(200).json(validate(body.code));
};
