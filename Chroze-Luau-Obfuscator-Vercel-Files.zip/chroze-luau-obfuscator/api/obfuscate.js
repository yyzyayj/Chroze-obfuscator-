'use strict';

const crypto = require('node:crypto');
const { transform } = require('../lib/luau');

module.exports = (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Use POST for this endpoint.' });
  }
  try {
    const body = req.body || {};
    const result = transform(body.code, body.options || {});
    const checksum = crypto.createHash('sha256').update(result.output, 'utf8').digest('hex');
    return res.status(200).json({
      output: result.output,
      checksum,
      sourceCharacters: body.code.length,
      outputCharacters: result.output.length,
      tokenCount: result.tokenCount,
      settings: result.settings,
      note: 'This is lexical source transformation, not a full Luau AST/VM compiler. Review and test generated code before use.'
    });
  } catch (error) {
    return res.status(400).json({ error: error.message || 'Unable to transform this source.' });
  }
};
