# Chroze Luau Obfuscator

This repository is a lightweight lexical Luau transformer, not a full AST/VM obfuscator.

## Deploy to Vercel from GitHub
1. Upload the **contents** of this folder to the root of your GitHub repository. Do not upload only the combined TXT bundle.
2. Confirm `index.html`, `app.js`, `style.css`, `package.json`, and `vercel.json` are at the repository root.
3. Confirm `api/obfuscate.js`, `api/validate.js`, and `lib/luau.js` are in their folders.
4. In Vercel, import the repository. Leave the framework preset as Other and the root directory as `./`.
5. Deploy, then open the deployment URL.

If your repository already contains the old single TXT file, you can keep it or delete it; it does not run the website.
